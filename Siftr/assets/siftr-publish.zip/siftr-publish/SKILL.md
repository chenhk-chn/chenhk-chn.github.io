---
name: siftr-publish
description: Publish Markdown briefings to a WebDAV space (Jianguoyun / 坚果云 or any HTTPS WebDAV) in the exact layout the Siftr iOS reader reads, and upload arbitrary files to Jianguoyun. Agent-agnostic — Hermes, Codex, ZCode or a human can follow it. Use for publishing/revising/inspecting Siftr content, deciding id vs. revision vs. duplicate, authoring reader-friendly Markdown, or uploading files over WebDAV.
---

# Siftr 内容发布（面向 Agent）

你是 **唯一的写入方**。Siftr App 只读：它 GET `manifest.json`，对比后再 GET 需要的正文。App 不会替你总结、配图、推荐、朗读或追问——这些都不做。**摘要、分类、标签、标题都由你写好**，写进元数据和 Markdown。

> 只想传任意文件到坚果云？看 §2 的 curl 原语即可，零依赖。想让 App 读到内容？先读 §1 的逻辑，再用 §5 的工具。

## 1. 先理解这套逻辑（决定你每次该怎么做）

### 1.1 两个标识，别混

| 标识 | 含义 | 谁决定 |
| --- | --- | --- |
| `id` | **这是哪一篇文章**。跨修订保持不变（如 `ai-daily`、`weekly-2026-w41`） | 你 |
| `content_sha256` | **这是哪份字节**。正文 UTF-8 字节的 SHA-256 | 工具自动算 |

读者端的已读/收藏记录挂在 `id` 上；内容变化靠 `content_sha256` 判断。

### 1.2 发布前的决策表

| 你手里的情况 | 怎么做 | 工具返回 |
| --- | --- | --- |
| 全新的一篇 | 起一个**新 id**，`publish` | `published` |
| 修订已发布的文章（改错字、补充、更新） | **沿用原 id**，改 Markdown，`publish` | `published`（旧版本文件保留，Manifest 指向新文件） |
| 与上次完全一样 | 什么都不用做（再跑也没副作用） | `unchanged` |
| 新 id，但正文与某篇**已发布**的字节完全相同 | **不要发**。这是重复内容，工具直接拒绝写入 | `duplicate`（含 `duplicate_of`，即已存在的 id） |
| 想用旧 id 发一篇完全不同的文章 | **禁止**。会覆盖该 id 的阅读状态；换新 id | — |

重复内容有两层防线：发布工具（`duplicate`，不写任何文件）和 App（读到相同 Markdown 只显示一份）。别靠 App 兜底——**别制造重复**。判断「是不是同一篇」用 id，不要用标题。

### 1.3 读者可以订阅多个 WebDAV 来源

用户可在 Siftr 里添加多个 WebDAV（例如两个坚果云目录、或坚果云加别家 WebDAV）。对你的影响：

- **一个目录 = 一个来源 = 一份 `manifest.json`**，一个目录只让一个发布方写。Manifest 是「读—改—写」，没有锁，两个 Agent 同时写同一个目录会丢更新。想多 Agent，就一人一个目录，让用户在 App 里各添加一次。
- **同一地址 App 只收一次**（大小写、末尾斜杠、默认端口 443、「服务器路径+目录」怎么拆分都视为同一地址）。你不需要、也不应该帮用户在多个目录里重复发同一篇来「保险」。
- **不同来源里内容完全相同的 Markdown，App 只显示一份**（保留较早添加的来源那份，已读/收藏同步到两份上）。所以「同一篇发布到两个目录」没有意义，除非用户明确要求镜像备份。
- 来源之间 id 互不冲突：甲目录的 `daily` 和乙目录的 `daily` 是两篇不同的文章，除非字节也相同。
- 写入一个目录时只操作这个目录。不要在 `SIFTR_DAV_URL` 之外读写；不要把一个来源的凭据用到另一个来源。

### 1.4 读者端如何对待你的文件（决定了「不可变」规则）

- 正文文件名含全文 SHA-256，**一版一文件，永不改、永不删**。修订就是新文件 + Manifest 改指新路径。App 要求同一路径下内容不可变，违反会被判定为损坏的 Manifest。
- **Manifest 永远最后写**。读者随时可能刷新：正文先落盘并回读校验，Manifest 最后更新，读者看到的状态就总是一致的。
- App 会把 `media/` 图片按路径缓存，不会因为你覆盖同名图片而刷新（见 §7）。

## 2. 凭据与上传原语

运行环境通过各自的安全管理器注入三个环境变量：

| 变量 | 含义 | 示例 |
| --- | --- | --- |
| `SIFTR_DAV_URL` | 内容根目录完整 URL（HTTPS） | `https://dav.jianguoyun.com/dav/Siftr/` |
| `SIFTR_DAV_USER` | 账号 | `user@example.com` |
| `SIFTR_DAV_APP_PASSWORD` | 第三方应用密码 | 见下 |

坚果云 WebDAV **不接受登录密码**。在网页版「账户信息 → 安全选项 → 第三方应用管理」为每个发布方单独创建应用密码（读者 App、每个 Agent 各一个，互不共用）。凭据只从环境变量读取，**绝不写入** Markdown、元数据、仓库、日志、命令行字面值或你的回复。

```bash
# 上传（PUT，覆盖同名文件）
curl -f -u "$SIFTR_DAV_USER:$SIFTR_DAV_APP_PASSWORD" -T daily.md "$SIFTR_DAV_URL/documents/daily_3f2a1b….md"
# 建目录（已存在返回 405，可忽略）
curl -s -o /dev/null -X MKCOL -u "$SIFTR_DAV_USER:$SIFTR_DAV_APP_PASSWORD" "$SIFTR_DAV_URL/documents/"
# 读取
curl -f -u "$SIFTR_DAV_USER:$SIFTR_DAV_APP_PASSWORD" "$SIFTR_DAV_URL/manifest.json"
# 列目录（坚果云禁止 GET 目录，必须 PROPFIND）
curl -s -X PROPFIND -H 'Depth: 1' -u "$SIFTR_DAV_USER:$SIFTR_DAV_APP_PASSWORD" "$SIFTR_DAV_URL/"
```

`-f` 让 4xx/5xx 以非零退出码暴露。变量引用一律加引号。

### 坚果云 WebDAV 行为速查（2026-10 实测）

| 场景 | 实际返回 |
| --- | --- |
| 认证 | HTTPS + Basic（`realm="nutstore"`），HTTP/2 |
| 凭据错误 | `401`，空响应体 |
| 父目录不存在时 GET/PUT | `409 AncestorsNotFound`——**不是 404**，先 `MKCOL` |
| GET 目录 | `403`；列目录必须 PROPFIND |
| 频率/流量超限 | `429`/`5xx`；指数退避，几次后放弃 |

## 3. 云端目录结构（Siftr 内容协议 v1）

```
$SIFTR_DAV_URL（如 https://dav.jianguoyun.com/dav/Siftr/）
├── manifest.json                      # 索引：App 的唯一入口
├── documents/
│   └── <id前缀>_<内容SHA-256>.md       # 不可变正文，一版一文件
└── media/                             # 可选：私有图片（App 认证加载）
    └── <名称>.png|.jpg|.jpeg|.gif|.webp
```

`manifest.json` 顶层：

| 字段 | 类型 | 约束 |
| --- | --- | --- |
| `schema_version` | int | 固定 `1` |
| `generated_at` | string | 带时区 ISO 8601；整份 ≤ 2 MiB |
| `publisher` | string? | 发布方标识，可选 |
| `documents` | array | ≤ 5000 条，按 `published_at` 倒序；`id` 不得重复 |

`documents[]` 每条：

| 字段 | 类型 | 约束 |
| --- | --- | --- |
| `id` | string | ASCII `[A-Za-z0-9._-]`，≤ 200 字符，跨修订不变 |
| `title` / `subtitle` | string / string? | 标题非空且 ≤ 200 字符 |
| `summary` | string | ≤ 1000 字符；App 列表和搜索都用它，认真写 |
| `category` | string | 非空；App 用它做筛选 |
| `tags` | [string]? | 可选；App 用它做筛选和搜索 |
| `published_at` / `updated_at` | string | 带时区 ISO 8601（`2026-10-13T09:00:00+08:00`）；`published_at` 决定排序与按月归档 |
| `path` | string | `documents/<id>_<sha256>.md`，由工具生成 |
| `content_sha256` | string | 正文 UTF-8 字节 SHA-256（64 位小写十六进制） |
| `size_bytes` | int | 真实字节数，单篇 ≤ 5 MiB |
| `reading_minutes` / `source_count` | int? | 非负 |

硬性规则：正文只允许 `documents/` 下 UTF-8 `.md`、非空、≤ 5 MiB；正文与链接里不得出现凭据；时间戳必须带时区。

## 4. 元数据 JSON（`--metadata`）

```json
{
  "id": "ai-daily",
  "title": "AI 每日简报：把信息读成理解",
  "summary": "三句话说清今天发生了什么、为什么重要。",
  "category": "AI 资讯",
  "tags": ["Agent", "模型"],
  "published_at": "2026-10-13T08:30:00+08:00",
  "updated_at": "2026-10-13T08:30:00+08:00",
  "reading_minutes": 3,
  "source_count": 5
}
```

必填：`id`、`title`、`summary`、`category`、`published_at`、`updated_at`。可选：`subtitle`、`tags`、`reading_minutes`、`source_count`、`publisher`。`path`、`content_sha256`、`size_bytes` 由工具填，不要手写。修订时 `published_at` 保持首次发布时间，`updated_at` 写本次时间。

## 5. 发布路径：按运行环境任选

### B. Python 3.10+（推荐）

`scripts/siftr_publish.py`（纯标准库，内置校验、幂等、重复检测、回读与退避，适合无人值守任务）：

```bash
python3 scripts/siftr_publish.py validate --markdown out/daily.md --metadata out/daily.json   # 完全离线
python3 scripts/siftr_publish.py status                                                        # 读远端 Manifest 概况
python3 scripts/siftr_publish.py publish  --markdown out/daily.md --metadata out/daily.json
```

`publish` 的 JSON 结果与你该做的事：

| `result` | 含义 | 你该做的 |
| --- | --- | --- |
| `published` | 新文章或修订已写入并回读确认 | 汇报 id、篇数、`generated_at` |
| `unchanged` | 远端已是这份内容 | 汇报「无变化」，不重试 |
| `duplicate` | 另一个 id（`duplicate_of`）已有完全相同的正文，**什么也没写** | 不要换 id 重发。若本意是修订那一篇，用 `duplicate_of` 的 id 并修改内容；否则汇报「重复，已跳过」 |
| 非零退出 + 错误信息 | 校验、认证、网络或回读失败 | 见 §9；Manifest 不会被改动，可安全重试 |

只在明确授权的发布请求或既定计划任务里执行 `publish`。

### A. 纯 shell（没有 Python 的主机）

用 `scripts/siftr_upload.sh`（POSIX sh + curl，自动建父目录并做 SHA-256 回读）：

```bash
scripts/siftr_upload.sh out/daily_3f2a1b.md documents/daily_3f2a1b.md
scripts/siftr_upload.sh chart.jpg media/chart.jpg
```

`manifest.json` 由你按 §1、§3 手工编排：GET 旧 Manifest → 本地合并 → 上传正文并确认回读哈希一致 → 最后 PUT `manifest.json` → GET 复核。合并时务必自己做 Python 版做的事：

1. 同 `id` 替换旧条目（沿用 `id`，更新 `path`、`content_sha256`、`size_bytes`、`updated_at`）。
2. **先查重**：若别的 `id` 已有相同 `content_sha256`，停止，按 `duplicate` 处理。
3. 按 `published_at` 倒序，刷新 `generated_at`，Manifest ≤ 2 MiB、≤ 5000 条。

## 6. Markdown 写作规范（按 App 渲染器实际能力）

支持：h1–h3、粗/斜体、行内代码、有序/无序列表、引用块、表格、代码块（横向滚动）、分隔线、可点击链接、图片。正文 18pt，随系统动态字号。

- 分节用 `##` 与 `###`；**不要用 `#`**（与文章大标题重复）。**每个标题都会成为 App 里的目录条目和书签锚点**，所以小节标题要简短、有信息、在同一篇里不重复。
- 首段直接给结论，段落短小；关键引语放引用块，对比信息用表格，命令与代码放代码块并标注语言。
- 链接锚文本要有意义，必须是 http(s)；App 会拦截指向用户 WebDAV 主机的链接，所以**不要链接到你自己的 WebDAV 地址**。
- 不写 HTML；不要在正文里放凭据。
- App 支持全文搜索：把读者会搜的专有名词、产品名、人名写进正文（而不只写在图里）。
- 不要写「相关推荐」「点此提问」「朗读」之类依赖 App 功能的话——这些功能不存在。

## 7. 图片策略

坚果云流量配额宝贵，按优先级：

1. **首选公开网络链接**：`![图表](https://example.com/chart.png)`，不消耗坚果云流量。
2. **确需私有图片才上传 `media/`，且必须先压缩**：长边 ≤ 1600px、JPEG 质量 70–80（或 WebP 80），单张目标 ≤ 300 KB。10 MiB 的协议上限只是兜底。

```bash
magick in.png -resize '1600x1600>' -quality 75 out.jpg                 # ImageMagick（v6 用 convert）
sips -Z 1600 -s format jpeg -s formatOptions 72 in.png --out out.jpg   # macOS 自带
```

私有图片用**纯相对路径**引用：`![架构图](media/architecture.png)`。App 用**该来源**的凭据认证加载并缓存。

- `media/` 只允许 `png/jpg/jpeg/gif/webp`；路径禁止 `..`、`%`、空格与控制字符。发布工具会拒绝违规引用。
- 图片不进 Manifest，App 按路径按需加载。
- 缓存以路径为键：**覆盖同名图片不会刷新已读设备**。改图用新文件名（`chart-v2.png`）并发布正文修订，旧图保留。

## 8. 纪律与汇报

- 发布前先 `validate`。脚本自带凭据泄露检查（`Authorization`、URL 内嵌账号密码、`SIFTR_DAV_APP_PASSWORD=` 等直接拒绝）。
- 永不删除远端历史文件；永不覆盖已有正文路径。
- 一个目录只有一个写入方（§1.3）。
- 汇报只含：命令结果（`published`/`unchanged`/`duplicate`/错误类别）、文档 id、篇数、时间。**不含**凭据、账号、私有本地路径。

## 9. 排错速查

| 现象 | 原因 | 做法 |
| --- | --- | --- |
| `认证失败` / 401 | 用了登录密码，或应用密码已撤销 | 让用户重新创建第三方应用密码 |
| 409 `AncestorsNotFound` | 父目录不存在 | `MKCOL` 后重试（Python 工具首次发布会自动初始化） |
| 429 / 5xx | 限流 | 退避重试；仍失败就放弃，下次计划任务再试 |
| `远端 Manifest 格式错误；已停止发布` | 远端 `manifest.json` 损坏或被他人改过 | **不要覆盖**。汇报给用户，由人决定如何恢复 |
| `Manifest 中存在重复 ID` | 远端被手工改坏 | 同上，不要自行覆盖 |
| `正文回读校验失败` | 上传被截断/中途改写 | Manifest 未改动；直接重试 |
| `duplicate` | 内容与别的 id 相同 | §1.2：不要重发 |
| App 里没看到新内容 | 读者需要手动下拉刷新；或用户没添加这个目录 | 确认目录地址与用户在 App 里添加的一致 |

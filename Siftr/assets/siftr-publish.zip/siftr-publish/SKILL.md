---
name: siftr-publish
description: Publish Markdown briefings and single-file static HTML pages to a WebDAV space (Jianguoyun / 坚果云 or any HTTPS WebDAV) in the exact layout the Siftr iOS reader reads, and upload arbitrary files to Jianguoyun. Agent-agnostic — Hermes, Codex, ZCode or a human can follow it. Use for publishing/revising/inspecting Siftr content, deciding id vs. revision vs. duplicate, authoring reader-friendly Markdown or small HTML demos, or uploading files over WebDAV.
---

# Siftr 内容发布（面向 Agent）

你是 **唯一的写入方**。Siftr App 只读：它 GET `manifest.json`，对比后再 GET 需要的正文。App 不会替你总结、配图、推荐、朗读或追问——这些都不做。**摘要、分类、标签、标题都由你写好**，写进元数据和正文。正文可以是 Markdown 简报，也可以是单文件静态网页（HTML，见 §6.1）。

> 只想传任意文件到坚果云？看 §2 的 curl 原语即可，零依赖。想让 App 读到内容？先读 §1 的逻辑，再用 §5 的工具。

## 1. 先理解这套逻辑（决定你每次该怎么做）

### 1.1 两个标识，别混

| 标识 | 含义 | 谁决定 |
| --- | --- | --- |
| `id` | **这是哪一篇文章**。跨修订保持不变（如 `ai-daily`、`weekly-2026-w41`） | 你 |
| `content_sha256` | **这是哪份字节**。正文 UTF-8 字节的 SHA-256 | 工具自动算 |

读者端的已读/收藏记录挂在 `id` 上；内容变化靠 `content_sha256` 判断。

### 1.2 发布前的决策表

| 你手里的情况 | 怎么做 | 工具返回 |
| --- | --- | --- |
| 全新的一篇 | 起一个**新 id**，`publish` | `published` |
| 修订已发布的文章（改错字、补充、更新） | **沿用原 id**，改 Markdown，`publish` | `published`（旧版本文件保留，Manifest 指向新文件） |
| 与上次完全一样 | 什么都不用做（再跑也没副作用） | `unchanged` |
| 新 id，但正文与某篇**已发布**的字节完全相同 | **不要发**。这是重复内容，工具直接拒绝写入 | `duplicate`（含 `duplicate_of`，即已存在的 id） |
| 想用旧 id 发一篇完全不同的文章 | **禁止**。会覆盖该 id 的阅读状态；换新 id | — |

重复内容有两层防线：发布工具（`duplicate`，不写任何文件）和 App（读到相同 Markdown 只显示一份）。别靠 App 兜底——**别制造重复**。判断「是不是同一篇」用 id，不要用标题。

### 1.3 读者可以订阅多个 WebDAV 来源

用户可在 Siftr 里添加多个 WebDAV（例如两个坚果云目录、或坚果云加别家 WebDAV）。对你的影响：

- **一个目录 = 一个来源 = 一份 `manifest.json`**，一个目录只让一个发布方写。Manifest 是「读—改—写」，没有锁，两个 Agent 同时写同一个目录会丢更新。想多 Agent，就一人一个目录，让用户在 App 里各添加一次。
- **同一地址 App 只收一次**（大小写、末尾斜杠、默认端口 443、「服务器路径+目录」怎么拆分都视为同一地址）。你不需要、也不应该帮用户在多个目录里重复发同一篇来「保险」。
- **不同来源里内容完全相同的 Markdown，App 只显示一份**（保留较早添加的来源那份，已读/收藏同步到两份上）。所以「同一篇发布到两个目录」没有意义，除非用户明确要求镜像备份。
- 来源之间 id 互不冲突：甲目录的 `daily` 和乙目录的 `daily` 是两篇不同的文章，除非字节也相同。
- 写入一个目录时只操作这个目录。不要在 `SIFTR_DAV_URL` 之外读写；不要把一个来源的凭据用到另一个来源。

### 1.4 读者端如何对待你的文件（决定了「不可变」规则）

- 正文文件名含全文 SHA-256，**一版一文件，永不改、永不删**。修订就是新文件 + Manifest 改指新路径。App 要求同一路径下内容不可变，违反会被判定为损坏的 Manifest。
- **Manifest 永远最后写**。读者随时可能刷新：正文先落盘并回读校验，Manifest 最后更新，读者看到的状态就总是一致的。
- App 会把 `media/` 图片按路径缓存，不会因为你覆盖同名图片而刷新（见 §7）。

## 2. 凭据与上传原语

运行环境通过各自的安全管理器注入三个环境变量：

| 变量 | 含义 | 示例 |
| --- | --- | --- |
| `SIFTR_DAV_URL` | 内容根目录完整 URL（HTTPS） | `https://dav.jianguoyun.com/dav/Siftr/` |
| `SIFTR_DAV_USER` | 账号 | `user@example.com` |
| `SIFTR_DAV_APP_PASSWORD` | 第三方应用密码 | 见下 |

坚果云 WebDAV **不接受登录密码**。在网页版「账户信息 → 安全选项 → 第三方应用管理」为每个发布方单独创建应用密码（读者 App、每个 Agent 各一个，互不共用）。凭据只从环境变量读取，**绝不写入** Markdown、元数据、仓库、日志、命令行字面值或你的回复。

```bash
# 上传（PUT，覆盖同名文件）
curl -f -u "$SIFTR_DAV_USER:$SIFTR_DAV_APP_PASSWORD" -T daily.md "$SIFTR_DAV_URL/documents/daily_3f2a1b….md"
# 建目录（已存在返回 405，可忽略）
curl -s -o /dev/null -X MKCOL -u "$SIFTR_DAV_USER:$SIFTR_DAV_APP_PASSWORD" "$SIFTR_DAV_URL/documents/"
# 读取
curl -f -u "$SIFTR_DAV_USER:$SIFTR_DAV_APP_PASSWORD" "$SIFTR_DAV_URL/manifest.json"
# 列目录（坚果云禁止 GET 目录，必须 PROPFIND）
curl -s -X PROPFIND -H 'Depth: 1' -u "$SIFTR_DAV_USER:$SIFTR_DAV_APP_PASSWORD" "$SIFTR_DAV_URL/"
```

`-f` 让 4xx/5xx 以非零退出码暴露。变量引用一律加引号。

### 坚果云 WebDAV 行为速查（2026-10 实测）

| 场景 | 实际返回 |
| --- | --- |
| 认证 | HTTPS + Basic（`realm="nutstore"`），HTTP/2 |
| 凭据错误 | `401`，空响应体 |
| 父目录不存在时 GET/PUT | `409 AncestorsNotFound`——**不是 404**，先 `MKCOL`（注意：**MKCOL 的 URL 不能带尾部斜杠**，`…/Siftr` 成功、`…/Siftr/` 返回 409；Python 工具已处理） |
| GET 目录 | `403`；列目录必须 PROPFIND |
| 频率/流量超限 | `429`/`5xx`；指数退避，几次后放弃 |

## 3. 云端目录结构（Siftr 内容协议 v2）

```
$SIFTR_DAV_URL（如 https://dav.jianguoyun.com/dav/Siftr/）
├── manifest.json                      # 索引：App 的唯一入口
├── documents/
│   ├── <id前缀>_<内容SHA-256>.md       # format = markdown，不可变，一版一文件
│   └── <id前缀>_<内容SHA-256>.html     # format = html，同样不可变
└── media/                             # 可选：Markdown 引用的私有图片（App 认证加载）
    └── <名称>.png|.jpg|.jpeg|.gif|.webp
```

`manifest.json` 顶层：

| 字段 | 类型 | 约束 |
| --- | --- | --- |
| `schema_version` | int | 固定 `2`（读到 `1` 时 Python 工具会自动升级，见下） |
| `generated_at` | string | 带时区 ISO 8601；整份 ≤ 2 MiB |
| `publisher` | string? | 发布方标识，可选 |
| `documents` | array | ≤ 5000 条，按 `published_at` 倒序；`id` 不得重复 |

`documents[]` 每条：

| 字段 | 类型 | 约束 |
| --- | --- | --- |
| `id` | string | ASCII `[A-Za-z0-9._-]`，≤ 200 字符，跨修订不变 |
| `format` | string | **必填**：`markdown` 或 `html`（工具按正文后缀自动填写） |
| `title` / `subtitle` | string / string? | 标题非空且 ≤ 200 字符 |
| `summary` | string | ≤ 1000 字符；App 列表和搜索都用它，认真写 |
| `category` | string | 非空；App 用它做筛选 |
| `tags` | [string]? | 可选；App 用它做筛选和搜索 |
| `published_at` / `updated_at` | string | 带时区 ISO 8601（`2026-10-13T09:00:00+08:00`）；`published_at` 决定排序与按月归档 |
| `path` | string | `documents/<id>_<sha256>.<md\|html>`，由工具生成；后缀必须与 `format` 一致 |
| `content_sha256` | string | 正文原始字节的 SHA-256（64 位小写十六进制） |
| `size_bytes` | int | 真实字节数，单篇 ≤ 5 MiB（两种格式相同） |
| `reading_minutes` / `source_count` | int? | 非负 |
| `format_options` | object? | 仅供对应格式的阅读器使用；`markdown`、`html` 目前没有定义，**不要写** |

硬性规则：正文是 `documents/` 下非空的 UTF-8 文件，≤ 5 MiB；正文与链接里不得出现凭据；时间戳必须带时区。`alternates` 是协议保留字段，不要写。

**版本与旧数据**：v1（`schema_version: 1`，没有 `format`）只有 Markdown。Python 工具读到 v1 时，会给每条补上 `"format": "markdown"`，下次发布时以 v2 写回（结果里带 `upgraded_to_schema_version: 2`）。**Siftr 1.0.0 只认识 v1**，看到 v2 会提示升级 App；所以在用户换成支持 v2 的版本之前，不要往他的目录发布。拿不准就先 `status`，看 `schema_version` 是多少。

**兼容未来格式**：Manifest 里出现你不认识的 `format`（比如以后的 `audio`），不要删也不要改，原样保留。Python 工具会自动这样处理。

## 4. 元数据 JSON（`--metadata`）

```json
{
  "id": "ai-daily",
  "title": "AI 每日简报：把信息读成理解",
  "summary": "三句话说清今天发生了什么、为什么重要。",
  "category": "AI 资讯",
  "tags": ["Agent", "模型"],
  "published_at": "2026-10-13T08:30:00+08:00",
  "updated_at": "2026-10-13T08:30:00+08:00",
  "reading_minutes": 3,
  "source_count": 5
}
```

必填：`id`、`title`、`summary`、`category`、`published_at`、`updated_at`。可选：`subtitle`、`tags`、`reading_minutes`、`source_count`、`publisher`。`format`、`path`、`content_sha256`、`size_bytes` 由工具填，不要手写；如果写了 `format`，必须和正文格式一致。修订时 `published_at` 保持首次发布时间，`updated_at` 写本次时间。

## 5. 发布路径：按运行环境任选

### B. Python 3.10+（推荐）

`scripts/siftr_publish.py`（纯标准库，内置校验、幂等、重复检测、回读与退避，适合无人值守任务）：

```bash
python3 scripts/siftr_publish.py validate --markdown out/daily.md --metadata out/daily.json   # 完全离线
python3 scripts/siftr_publish.py status                                                        # 远端概况：schema_version、篇数、各格式数量
python3 scripts/siftr_publish.py publish  --markdown out/daily.md --metadata out/daily.json
python3 scripts/siftr_publish.py publish  --html out/sort-demo.html --metadata out/sort-demo.json   # 单文件静态网页
python3 scripts/siftr_publish.py publish  --file out/anything.md --metadata out/meta.json           # 按后缀识别格式
```

`publish` 的 JSON 结果与你该做的事：

| `result` | 含义 | 你该做的 |
| --- | --- | --- |
| `published` | 新文章或修订已写入并回读确认 | 汇报 id、篇数、`generated_at` |
| `unchanged` | 远端已是这份内容 | 汇报「无变化」，不重试 |
| `duplicate` | 另一个 id（`duplicate_of`）已有完全相同的正文，**什么也没写** | 不要换 id 重发。若本意是修订那一篇，用 `duplicate_of` 的 id 并修改内容；否则汇报「重复，已跳过」 |
| 非零退出 + 错误信息 | 校验、认证、网络或回读失败 | 见 §9；Manifest 不会被改动，可安全重试 |

只在明确授权的发布请求或既定计划任务里执行 `publish`。

### A. 纯 shell（没有 Python 的主机）

用 `scripts/siftr_upload.sh`（POSIX sh + curl，自动建父目录并做 SHA-256 回读）：

```bash
scripts/siftr_upload.sh out/daily_3f2a1b.md documents/daily_3f2a1b.md
scripts/siftr_upload.sh chart.jpg media/chart.jpg
```

`manifest.json` 由你按 §1、§3 手工编排：GET 旧 Manifest → 本地合并 → 上传正文并确认回读哈希一致 → 最后 PUT `manifest.json` → GET 复核。合并时务必自己做 Python 版做的事：

1. 旧 Manifest 是 v1 时：每条补 `"format": "markdown"`，顶层改为 `"schema_version": 2`。
2. 同 `id` 替换旧条目（沿用 `id`，更新 `format`、`path`、`content_sha256`、`size_bytes`、`updated_at`）。同一个 id 从 Markdown 改成 HTML 也属于修订。
3. **先查重**：如果另一个 `id` 已有相同的 `format` + `content_sha256`，就停止，按 `duplicate` 处理。
4. 不认识的 `format` 条目原样保留。
5. 按 `published_at` 倒序，刷新 `generated_at`，Manifest ≤ 2 MiB、≤ 5000 条。

## 6. Markdown 写作规范（按 App 渲染器实际能力）

支持：h1–h6、粗/斜体、删除线、行内代码、有序/无序列表、任务列表（`- [ ]` / `- [x]`）、引用块、提示块（引用块首行写 `[!NOTE]` 等）、表格（横向滚动）、代码块（显示语言名、可一键复制；代码横向滚动，`text`/`markdown` 或不标语言的块自动换行）、分隔线、可点击链接、图片（圆角，可点开放大）、脚注（`[^1]`，显示为上标数字，正文末尾汇总为「参考」）、LaTeX 公式（`$…$`、`$$…$$`）。正文 18pt，随系统动态字号；读者可选黑体或宋体。

- 分节用 `##` 与 `###`；**不要用 `#`**（与文章大标题重复；开头与标题相同的 `#` 会被 App 自动隐藏）。**每个标题都会成为 App 里的目录条目**，所以小节标题要简短、有信息、在同一篇里不重复。
- 首段直接给结论，段落短小；关键引语放引用块，对比信息用表格，命令与代码放代码块并在开头围栏后标注语言（如 `python`、`bash`），App 会显示语言名。
- 需要读者特别留意的一句话用 GitHub 提示块（示例见下），类型只有 `NOTE`（说明）、`TIP`（提示）、`IMPORTANT`（重要）、`WARNING`（注意）、`CAUTION`（警告）；类型后面可以跟一个自定义标题。每篇最多两三个，滥用会失去重点。
- 待办或核对清单用任务列表；已完成项会以勾选、弱化显示。
- 图片独占一段（前后空行）时按整幅配图显示；`![替代文字](地址 "图注")` 中的引号部分显示为图注，没有图注时显示替代文字。
- 链接锚文本要有意义，必须是 http(s)；App 会拦截指向用户 WebDAV 主机的链接，所以**不要链接到你自己的 WebDAV 地址**。
- 引用同一内容空间里的另一篇时写 `[上一期](documents/<那篇的 id>.md)`（例如 `documents/ai-daily-2026-10-13.md`）；链接到网页就用 `.html` 后缀，比如 `documents/sort-demo.html`。App 会在内部直接打开那篇，修订后链接依然有效。该文章必须仍在 Manifest 里，否则读者会看到“这篇文章不在当前列表中”。
- **段内不折行**：一个段落写成一行，段与段之间空一行。段内的硬换行会被渲染成空格，中文里就成了多余的空隙。
- **全角标点后不加空格**：`。`、`，`、`：`、`）` 等后面直接接下一个字；中文与英文、数字之间是否加空格保持全文一致即可。
- 写金额直接写 `$20`。只有整篇的 `$` 都能两两配成公式（`$` 内侧不贴空格、右侧不紧跟数字）时 App 才渲染公式，所以**公式和美元金额不要出现在同一篇里**；需要时把金额写成「20 美元」或 `USD 20`。
- Markdown 里不写 HTML（要做网页就用 §6.1 的 HTML 格式）；不要在正文里放凭据。
- App 支持全文搜索：把读者会搜的专有名词、产品名、人名写进正文（而不只写在图里）。
- 不要写「相关推荐」「点此提问」「朗读」之类依赖 App 功能的话——这些功能不存在。

```markdown
> [!TIP] 读这一节的方法
> 先看表格里的价格，再看备注。
```

## 6.1 HTML 静态网页（`format: html`）

适合交互演示、可视化、动画讲解这类用 Markdown 表达不出来的内容。App 用隔离的 WebKit 打开，**打开即运行**。

- **单个 `.html` 文件**，CSS 和 JS 写在文件里。不要拆出相对路径的 css、js 或图片，App 不会加载它们。
- **可以从公共 CDN 引用库、字体和图片**，但必须用 `https://`。CDN 资源由读者手机直接请求，不经过坚果云，也不占坚果云流量。发布工具会拒绝 `http://` 资源。
- **不要依赖后端**：没有服务器，没有登录，表单提交不会有响应。
- **不要引用你的 WebDAV 地址**：App 会拦截所有指向用户 WebDAV 主机的请求，发布工具也会拒绝。私有图片请改用公开地址，或者转成 data URI 内联。
- **页面里的外链**会在系统浏览器里打开，`target=_blank` 也一样。页内锚点（`#step-2`）照常可用。
- **移动端优先**：读者在手机上竖屏阅读。写上 `<meta name="viewport" content="width=device-width, initial-scale=1">`（漏写的话 App 会自动补上），布局要能适应 320–430pt 的宽度，可点控件不小于 44pt。
- **支持深色模式更好**：用 `@media (prefers-color-scheme: dark)`。App 不会改网页的样式。
- **搜索**：App 会提取页面里的可见文字参与全文搜索，JS 动态生成的文字搜不到。关键名词要写在 HTML 里，同时写进 `summary` 和 `tags`。
- **标题**写在元数据的 `title` 里，列表和阅读页都用它；页面里的 `<title>` 不会显示。
- **讲解和演示分开时**：讲解写成 Markdown，演示写成 HTML，分别用两个 id 发布。然后在 Markdown 里用 `[打开演示](documents/<演示的 id>.html)` 链接过去，App 会在站内打开。

## 7. 图片策略

坚果云流量配额宝贵，按优先级：

1. **首选公开网络链接**：`![图表](https://example.com/chart.png)`，不消耗坚果云流量。
2. **确需私有图片才上传 `media/`，且必须先压缩**：长边 ≤ 1600px、JPEG 质量 70–80（或 WebP 80），单张目标 ≤ 300 KB。10 MiB 的协议上限只是兜底。

```bash
magick in.png -resize '1600x1600>' -quality 75 out.jpg                 # ImageMagick（v6 用 convert）
sips -Z 1600 -s format jpeg -s formatOptions 72 in.png --out out.jpg   # macOS 自带
```

私有图片用**纯相对路径**引用：`![架构图](media/architecture.png)`。App 用**该来源**的凭据认证加载并缓存。

- `media/` 只允许 `png/jpg/jpeg/gif/webp`；路径禁止 `..`、`%`、空格与控制字符。发布工具会拒绝违规引用。
- 图片不进 Manifest，App 按路径按需加载。
- 缓存以路径为键：**覆盖同名图片不会刷新已读设备**。改图用新文件名（`chart-v2.png`）并发布正文修订，旧图保留。

## 8. 纪律与汇报

- 发布前先 `validate`。脚本自带凭据泄露检查（`Authorization`、URL 内嵌账号密码、`SIFTR_DAV_APP_PASSWORD=` 等直接拒绝）。
- 永不删除远端历史文件；永不覆盖已有正文路径。
- 一个目录只有一个写入方（§1.3）。
- 汇报只含：命令结果（`published`/`unchanged`/`duplicate`/错误类别）、文档 id、篇数、时间。**不含**凭据、账号、私有本地路径。

## 9. 排错速查

| 现象 | 原因 | 做法 |
| --- | --- | --- |
| `认证失败` / 401 | 用了登录密码，或应用密码已撤销 | 让用户重新创建第三方应用密码 |
| 409 `AncestorsNotFound` | 父目录不存在 | `MKCOL` 后重试（Python 工具把 409 与 404 同样视为「还没有 Manifest」，首次发布会自动初始化目录） |
| 429 / 5xx | 限流 | 退避重试；仍失败就放弃，下次计划任务再试 |
| `远端 Manifest 格式错误；已停止发布` | 远端 `manifest.json` 损坏或被他人改过 | **不要覆盖**。汇报给用户，由人决定如何恢复 |
| `Manifest 中存在重复 ID` | 远端被手工改坏 | 同上，不要自行覆盖 |
| `正文回读校验失败` | 上传被截断/中途改写 | Manifest 未改动；直接重试 |
| `duplicate` | 内容与别的 id 相同 | §1.2：不要重发 |
| `HTML 不能从 http:// 加载资源` | 页面引用了明文资源 | 改成 `https://` 的地址 |
| `正文引用了内容空间所在的 WebDAV 主机` | 正文里写了用户的坚果云地址 | 删掉；私有图片改用公开地址或 data URI |
| `不支持的 Manifest 协议版本` | 远端是比工具更新的协议 | 不要覆盖；更新 Skill 后再发布 |
| 读者 App 提示“需要更新版本” | 目录已升级到 v2，读者还在用 1.0.0 | 让用户更新 Siftr |
| App 里没看到新内容 | 读者需要手动下拉刷新；或用户没添加这个目录 | 确认目录地址与用户在 App 里添加的一致 |

#!/bin/sh
# Siftr WebDAV uploader — POSIX sh + curl only, for hosts without Python.
# Uploads one file into the Siftr content space, creating missing parent
# collections, then verifies the readback SHA-256.
#
# Usage:   siftr_upload.sh <local-file> <remote-relative-path>
#   e.g.   siftr_upload.sh brief_3f2a.md documents/brief_3f2a.md
#          siftr_upload.sh chart.jpg media/chart.jpg
#
# Env:     SIFTR_DAV_URL  SIFTR_DAV_USER  SIFTR_DAV_APP_PASSWORD
set -eu

[ "$#" -eq 2 ] || { echo "usage: $0 <local-file> <remote-relative-path>" >&2; exit 2; }
file=$1; remote=$2
[ -f "$file" ] || { echo "not a file: $file" >&2; exit 2; }
: "${SIFTR_DAV_URL:?SIFTR_DAV_URL is required}" \
  "${SIFTR_DAV_USER:?SIFTR_DAV_USER is required}" \
  "${SIFTR_DAV_APP_PASSWORD:?SIFTR_DAV_APP_PASSWORD is required}"

case $remote in
  /*|*..*|*'%'*|*'\'*|*:*|*'?'*|'#'*|*' '*|*"$(printf '\t')"*)
    echo "unsafe remote path: $remote" >&2; exit 2 ;;
esac
case $remote in */*) dir=${remote%/*} ;; *) dir= ;; esac

if command -v sha256sum >/dev/null 2>&1; then SHA='sha256sum'; else SHA='shasum -a 256'; fi
root=${SIFTR_DAV_URL%/}/
auth="$SIFTR_DAV_USER:$SIFTR_DAV_APP_PASSWORD"

# Create missing parent collections; 200/405 mean it already exists.
if [ -n "$dir" ]; then
  created=
  oldIFS=$IFS; IFS=/
  for part in $dir; do
    created=${created:+$created/}$part
    code=$(curl -s -o /dev/null -w '%{http_code}' -u "$auth" -X MKCOL "$root$created/")
    case $code in 200|201|405) ;; *) echo "MKCOL $created/ failed: HTTP $code" >&2; exit 1 ;; esac
  done
  IFS=$oldIFS
fi

code=$(curl -s -o /dev/null -w '%{http_code}' -u "$auth" -T "$file" "$root$remote")
case $code in 200|201|204) ;; *) echo "PUT $remote failed: HTTP $code" >&2; exit 1 ;; esac

local_sha=$($SHA "$file" | cut -d' ' -f1)
remote_sha=$(curl -sf -u "$auth" "$root$remote" | $SHA | cut -d' ' -f1)
[ "$local_sha" = "$remote_sha" ] || { echo "readback hash mismatch for $remote" >&2; exit 1; }

echo "uploaded $remote ($(wc -c < "$file" | tr -d ' ') bytes, sha256 $(printf %s "$local_sha" | cut -c1-12)...)"

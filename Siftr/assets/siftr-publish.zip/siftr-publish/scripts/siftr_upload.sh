#!/bin/sh
# Siftr WebDAV uploader — POSIX sh + curl only, for hosts without Python.
# Uploads one file into the Siftr content space, creating missing parent
# collections, then verifies the readback SHA-256.
#
# Usage:   siftr_upload.sh <local-file> <remote-relative-path>
#   e.g.   siftr_upload.sh brief_3f2a.md documents/brief_3f2a.md
#          siftr_upload.sh chart.jpg media/chart.jpg
#
# Env:     SIFTR_DAV_URL  SIFTR_DAV_USER  SIFTR_DAV_APP_PASSWORD
set -eu

[ "$#" -eq 2 ] || { echo "usage: $0 <local-file> <remote-relative-path>" >&2; exit 2; }
file=$1; remote=$2
[ -f "$file" ] || { echo "not a file: $file" >&2; exit 2; }
: "${SIFTR_DAV_URL:?SIFTR_DAV_URL is required}" \
  "${SIFTR_DAV_USER:?SIFTR_DAV_USER is required}" \
  "${SIFTR_DAV_APP_PASSWORD:?SIFTR_DAV_APP_PASSWORD is required}"

# Deliberately accept only a portable ASCII subset; no URL fragments or traversal.
case $remote in
  ''|/*|*/|*//*|*..*|*[!A-Za-z0-9_./-]*)
    echo "unsafe remote path" >&2; exit 2 ;;
esac
case /$remote/ in */./*) echo "unsafe remote path" >&2; exit 2 ;; esac
case $SIFTR_DAV_URL in
  https://*) ;;
  *) echo "HTTPS WebDAV URL required" >&2; exit 2 ;;
esac
case ${SIFTR_DAV_URL#https://} in
  ''|/*|*'@'*|*'?'*|*'#'*|*'%'*|*[!A-Za-z0-9_./:-]*)
    echo "use an ASCII WebDAV URL without credentials, query or fragment" >&2; exit 2 ;;
esac
case /${SIFTR_DAV_URL#https://}/ in */../*|*/./*) echo "unsafe URL" >&2; exit 2 ;; esac
case $remote in */*) dir=${remote%/*} ;; *) dir= ;; esac

# Keep credentials out of process arguments. The temporary curl config is private.
umask 077
scratch=$(mktemp -d)
trap 'rm -rf "$scratch"' EXIT HUP INT TERM
case $SIFTR_DAV_USER in *:*) echo "invalid username" >&2; exit 2 ;; esac
# Reject newlines/control characters before serialising curl configuration.
case $SIFTR_DAV_USER$SIFTR_DAV_APP_PASSWORD in *'
'*) echo "credentials contain newline" >&2; exit 2 ;; esac
if printf '%s' "$SIFTR_DAV_USER$SIFTR_DAV_APP_PASSWORD" | LC_ALL=C grep '[[:cntrl:]]' >/dev/null; then
  echo "credentials contain control characters" >&2; exit 2
fi
escaped=$(printf '%s' "$SIFTR_DAV_USER:$SIFTR_DAV_APP_PASSWORD" | sed 's/\\/\\\\/g; s/"/\\"/g')
printf 'user = "%s"\n' "$escaped" > "$scratch/auth"
request() {
  curl -q --config "$scratch/auth" --proto '=https' --connect-timeout 10 --max-time 60 "$@"
}

if command -v sha256sum >/dev/null 2>&1; then SHA='sha256sum';
elif command -v shasum >/dev/null 2>&1; then SHA='shasum -a 256';
else echo 'sha256sum or shasum required' >&2; exit 2; fi
root=${SIFTR_DAV_URL%/}/
code=$(request -sS -o /dev/null -w '%{http_code}' -X MKCOL "${root%/}")
case $code in 200|201|405) ;; *) echo "MKCOL root failed: HTTP $code" >&2; exit 1 ;; esac

# Create missing parent collections; 200/405 mean it already exists.
if [ -n "$dir" ]; then
  created=
  oldIFS=$IFS; IFS=/
  for part in $dir; do
    created=${created:+$created/}$part
    code=$(request -sS -o /dev/null -w '%{http_code}' -X MKCOL "$root$created")
    case $code in 200|201|405) ;; *) echo "MKCOL $created/ failed: HTTP $code" >&2; exit 1 ;; esac
  done
  IFS=$oldIFS
fi

code=$(request -sS -o /dev/null -w '%{http_code}' -T "$file" "$root$remote")
case $code in 200|201|204) ;; *) echo "PUT $remote failed: HTTP $code" >&2; exit 1 ;; esac

local_sha=$($SHA "$file" | cut -d' ' -f1)
request -fsS -o "$scratch/readback" "$root$remote"
remote_sha=$($SHA "$scratch/readback" | cut -d' ' -f1)
[ "$local_sha" = "$remote_sha" ] || { echo "readback hash mismatch for $remote" >&2; exit 1; }

echo "uploaded $remote ($(wc -c < "$file" | tr -d ' ') bytes, sha256 $(printf %s "$local_sha" | cut -c1-12)...)"

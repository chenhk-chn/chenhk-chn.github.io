#!/usr/bin/env python3
"""Siftr Content Protocol v2 publisher (Markdown and HTML). Standard library; secrets only from environment."""
import argparse
import base64
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

MANIFEST_LIMIT = 2 * 1024 * 1024
SCHEMA_VERSION = 2
FORMAT_NAME = re.compile(r"[a-z][a-z0-9-]{0,31}")

class PublishError(Exception):
    pass

def timestamp(value):
    if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})", value):
        raise PublishError("时间字段必须是含时区的 ISO 8601 时间。")
    try:
        return dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        raise PublishError("时间字段无效。") from None

def safe_path(path, document=False, format_name=None):
    """document=True: a body path under documents/ with an extension; registered formats must use their own."""
    if not isinstance(path, str) or not path or any(c in path for c in "\\%:?#") or any(ord(c) < 32 for c in path):
        raise PublishError("内容路径不安全。")
    parts = path.split("/")
    if any(p in ("", ".", "..") for p in parts) or any(c.isspace() for c in path):
        raise PublishError("内容路径不安全。")
    if document:
        ext = extension(path)
        if len(parts) < 2 or parts[0] != "documents" or not ext or len(ext) > 10 or not ext.isascii() or not ext.isalnum():
            raise PublishError("内容路径不安全。")
        known = FORMATS.get(format_name or "markdown")
        if known and ext not in known["extensions"]:
            raise PublishError("内容路径不安全：后缀与格式不符。")

def extension(path):
    name = path.rsplit("/", 1)[-1]
    if "." not in name or name.startswith(".") and name.count(".") == 1:
        return ""
    return name.rsplit(".", 1)[-1].lower()

def validate_document(d):
    if not isinstance(d, dict):
        raise PublishError("文档元数据必须是对象。")
    for field in ("id", "title", "category"):
        if not isinstance(d.get(field), str) or not d[field].strip():
            raise PublishError(f"{field} 必须为非空字符串。")
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,199}", d["id"]):
        raise PublishError("发布 ID 必须是最多 200 字符的 ASCII 标识。")
    if len(d["title"]) > 200 or not isinstance(d.get("summary"), str) or len(d["summary"]) > 1000:
        raise PublishError("标题或摘要超出限制或缺失。")
    for key in ("published_at", "updated_at"):
        timestamp(d.get(key))
    if not isinstance(d.get("format"), str) or not FORMAT_NAME.fullmatch(d["format"]):
        raise PublishError("format 必须是格式名（如 markdown、html）。")
    safe_path(d.get("path"), document=True, format_name=d["format"])
    if not isinstance(d.get("content_sha256"), str) or not re.fullmatch(r"[0-9a-f]{64}", d["content_sha256"]):
        raise PublishError("SHA-256 格式错误。")
    limit = FORMATS[d["format"]]["limit"] if d["format"] in FORMATS else None
    if type(d.get("size_bytes")) is not int or d["size_bytes"] < 0 or (limit is not None and d["size_bytes"] > limit):
        raise PublishError("文档大小超过限制或字段无效。")
    if "format_options" in d and not isinstance(d["format_options"], dict):
        raise PublishError("format_options 必须是对象。")
    for key in ("reading_minutes", "source_count"):
        if key in d and (type(d[key]) is not int or d[key] < 0):
            raise PublishError(f"{key} 必须是非负整数。")
    if "tags" in d and (not isinstance(d["tags"], list) or not all(isinstance(t, str) for t in d["tags"])):
        raise PublishError("tags 必须是字符串数组。")
    if "subtitle" in d and not isinstance(d["subtitle"], str):
        raise PublishError("subtitle 必须是字符串。")

def validate_manifest(data):
    if len(data) > MANIFEST_LIMIT:
        raise PublishError("Manifest 超过 2 MiB。")
    try:
        m = json.loads(data)
    except (ValueError, UnicodeError):
        raise PublishError("远端 Manifest 格式错误；已停止发布。") from None
    if not isinstance(m, dict) or type(m.get("schema_version")) is not int or m["schema_version"] not in (1, SCHEMA_VERSION):
        raise PublishError("不支持的 Manifest 协议版本。")
    timestamp(m.get("generated_at"))
    docs = m.get("documents")
    if not isinstance(docs, list) or len(docs) > 5000:
        raise PublishError("documents 必须是最多 5000 条的数组。")
    if m["schema_version"] == 1:
        # Protocol v1 is Markdown only. Upgrade in memory; the next write stores v2 (Docs/ContentProtocol.md §7).
        for d in docs:
            if isinstance(d, dict):
                d["format"] = "markdown"
        m["schema_version"] = SCHEMA_VERSION
        m["upgraded_from"] = 1  # in-memory marker for publish(); never written
    ids = set()
    for d in docs:
        validate_document(d)
        if d["id"] in ids:
            raise PublishError("Manifest 中存在重复 ID。")
        ids.add(d["id"])
    return m

CREDENTIAL = re.compile(r"(https?://[^\s/\"'<>]+:[^\s/\"'<>]+@|Authorization\s*:|SIFTR_DAV_APP_PASSWORD\s*=)", re.I)

def check_markdown(text):
    if re.search(r"<\s*(script|iframe|object|embed)\b", text, re.I):
        raise PublishError("Markdown 包含不允许的 HTML 内容。")
    if text.count("```") % 2:
        raise PublishError("Markdown 代码围栏未闭合。")
    for link in re.findall(r"\]\(([^\s)]+)", text):
        if link.startswith("media/"):
            if not link.lower().endswith((".png", ".jpg", ".jpeg", ".gif", ".webp")):
                raise PublishError("media/ 引用必须是 png/jpg/jpeg/gif/webp 图片。")
            safe_path(link)
            continue
        if link.startswith("documents/"):
            target = link.split("#")[0]
            if link_format(target):
                safe_path(target)
                continue
            raise PublishError("documents/ 链接必须指向已注册格式的文章（.md、.html）。")
        u = urllib.parse.urlsplit(link)
        if u.scheme not in ("https", "http") or not u.hostname or u.username or u.password:
            raise PublishError("正文链接必须是无凭证的 HTTP(S) 地址。")

HTML_INSECURE = re.compile(r"""(?:\bsrc\s*=\s*["']?|url\(\s*["']?|@import\s+["']?|\bimport\s*\(?\s*["']|\bfrom\s+["'])http://""", re.I)

def check_html(text):
    if not re.search(r"<\s*(html|body|head|div|p|main|section|canvas|svg|script|style|h[1-6])\b", text, re.I):
        raise PublishError("HTML 文件里没有找到任何 HTML 元素。")
    if HTML_INSECURE.search(text):
        raise PublishError("HTML 不能从 http:// 加载资源，请改用 https://。")

# Registered formats (Docs/ContentProtocol.md §5). Adding a format: one row here, one entry in SiftrCore's
# ContentFormat.registry, a viewer in the app.
FORMATS = {
    "markdown": {"extensions": ("md",), "limit": 5 * 1024 * 1024, "text": True, "check": check_markdown},
    "html": {"extensions": ("html", "htm"), "limit": 5 * 1024 * 1024, "text": True, "check": check_html},
}
DOCUMENT_LIMIT = max(f["limit"] for f in FORMATS.values())

def link_format(path):
    ext = extension(path)
    return next((name for name, f in FORMATS.items() if ext in f["extensions"]), None)

def prepare(body, metadata, format_name=None):
    """Reads a body and its metadata JSON, checks both, and fills path, SHA, size and format."""
    format_name = format_name or link_format(str(body))
    if format_name not in FORMATS:
        raise PublishError("无法识别正文格式；支持：" + "、".join(f"{n}（.{', .'.join(f['extensions'])}）" for n, f in FORMATS.items()) + "。")
    spec = FORMATS[format_name]
    data = Path(body).read_bytes()
    if not data or len(data) > spec["limit"]:
        raise PublishError(f"正文为空或超过 {spec['limit'] // (1024 * 1024)} MiB。")
    try:
        d = json.loads(Path(metadata).read_text(encoding="utf-8"))
        text = data.decode("utf-8") if spec["text"] else None
    except (UnicodeError, ValueError):
        raise PublishError("正文必须是 UTF-8，元数据必须是 JSON。") from None
    if text is not None:
        if not text.strip():
            raise PublishError("正文不得为空白。")
        if CREDENTIAL.search(text):
            raise PublishError("正文可能含有凭证，禁止发布。")
        spec["check"](text)
    if not isinstance(d, dict) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,199}", str(d.get("id", ""))):
        raise PublishError("发布 ID 必须是最多 200 字符的 ASCII 标识。")
    if CREDENTIAL.search(json.dumps(d, ensure_ascii=False)):
        raise PublishError("元数据可能含有凭证，禁止发布。")
    if "format" in d and d["format"] != format_name:
        raise PublishError(f"元数据里的 format（{d['format']}）与正文格式（{format_name}）不一致。")
    d.pop("alternates", None)  # reserved by the protocol, not defined yet
    sha = hashlib.sha256(data).hexdigest()
    # Full hash prevents rare hash8 collisions from violating immutable paths.
    d.update(format=format_name, path=f"documents/{d['id'][:180]}_{sha}.{spec['extensions'][0]}", content_sha256=sha, size_bytes=len(data))
    validate_document(d)
    return d, data

def reject_own_host(data, dav):
    """A body must never point at the WebDAV host: the app blocks it, and it would hint at the account."""
    host = urllib.parse.urlsplit(dav.root).hostname
    if host and host.lower().encode() in data.lower():
        raise PublishError("正文引用了内容空间所在的 WebDAV 主机；App 会拦截这类地址，请删除后重试。")

def content_type(path):
    ext = extension(path)
    return {"json": "application/json", "md": "text/markdown; charset=utf-8", "html": "text/html; charset=utf-8",
            "htm": "text/html; charset=utf-8"}.get(ext, "application/octet-stream")

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise PublishError("服务器重定向已被拒绝；不会转发凭证。")

class DAV:
    def __init__(self):
        self.root = os.environ.get("SIFTR_DAV_URL", "")
        user = os.environ.get("SIFTR_DAV_USER", "")
        password = os.environ.get("SIFTR_DAV_APP_PASSWORD", "")
        missing = [key for key in ("SIFTR_DAV_URL", "SIFTR_DAV_USER", "SIFTR_DAV_APP_PASSWORD") if not os.environ.get(key)]
        if missing:
            raise PublishError("缺少配置：" + "、".join(missing) + "。请按 SKILL.md 的首次配置指引设置；不要把密码发到对话中。")
        try:
            u = urllib.parse.urlsplit(self.root)
            u.port
        except ValueError:
            raise PublishError("WebDAV 地址格式无效。") from None
        if u.scheme != "https" or not u.hostname or u.username or u.password or u.query or u.fragment or not user or not password or ":" in user:
            raise PublishError("请通过运行环境提供有效 HTTPS 地址、账号及应用密码。")
        if u.path.strip("/"):
            safe_path(u.path.strip("/"))
        if not self.root.isascii() or any(c.isspace() or ord(c) < 32 for c in self.root):
            raise PublishError("WebDAV 地址请使用 ASCII 主机名与目录，不得含空格或控制字符。")
        self.root = self.root.rstrip("/") + "/"
        self.auth = "Basic " + base64.b64encode(f"{user}:{password}".encode()).decode()
        self.opener = urllib.request.build_opener(NoRedirect())

    def request(self, method, path="", data=None, missing_ok=False):
        if path:
            safe_path(path)
        # 坚果云对带尾斜杠的 MKCOL 返回 409；空路径（根目录）必须用去斜杠的 URL。
        url = (self.root + urllib.parse.quote(path, safe="/")) if path else self.root.rstrip("/")
        for attempt in range(3):
            req = urllib.request.Request(url, data=data, method=method, headers={"Authorization": self.auth, "Content-Type": content_type(path)})
            try:
                with self.opener.open(req, timeout=30) as response:
                    limit = MANIFEST_LIMIT if path.endswith(".json") else DOCUMENT_LIMIT
                    result = response.read(limit + 1)
                    if len(result) > limit:
                        raise PublishError("远端响应超过大小限制。")
                    return result
            except urllib.error.HTTPError as e:
                # 空目录首次发布时，坚果云对「父目录不存在」的路径返回 409 AncestorsNotFound
                # 而不是 404；两种都算「还没有 Manifest」，让 publish 走 initialize() 建目录。
                if missing_ok and e.code in (404, 409):
                    return None
                if e.code in (401, 403):
                    raise PublishError("认证失败，请检查应用密码。") from None
                if method == "MKCOL" and e.code == 405:
                    return b""
                if e.code == 429 or 500 <= e.code <= 599:
                    delay = (e.headers or {}).get("Retry-After", "")
                    delay = float(delay) if delay.isdigit() else 2 ** attempt
                    if attempt < 2 and delay <= 30:
                        time.sleep(max(1, delay)); continue
                    raise PublishError("服务器限流或暂时不可用，请稍后重试。") from None
                raise PublishError(f"WebDAV {method} 失败（HTTP {e.code}）。") from None
            except (urllib.error.URLError, TimeoutError):
                if attempt < 2:
                    time.sleep(2 ** attempt); continue
                raise PublishError("无法连接服务器，请检查网络。") from None
        raise PublishError("请求失败。")

    def initialize(self):
        # MKCOL root, documents and media only; never delete or overwrite historical files.
        self.request("MKCOL")
        self.request("MKCOL", "documents")
        self.request("MKCOL", "media")

def publish(dav, document, data, strict=True):
    existing = dav.request("GET", "manifest.json", missing_ok=True)
    upgraded = False
    if existing is None:
        dav.initialize()
        m = {"schema_version": SCHEMA_VERSION, "generated_at": dt.datetime.now(dt.timezone.utc).isoformat(), "documents": []}
        # The publisher identity is optional metadata, not a constant of this script.
        publisher = document.get("publisher")
        if isinstance(publisher, str) and publisher.strip():
            m["publisher"] = publisher.strip()
    else:
        m = validate_manifest(existing)
        upgraded = m.get("upgraded_from") is not None
        m.pop("upgraded_from", None)
    previous = next((x for x in m["documents"] if x["id"] == document["id"]), None)
    # The reader shows identical Markdown once, so a second id carrying the same bytes is only noise.
    # Nothing is written; the caller learns which published id already holds this content.
    twin = next((x for x in m["documents"] if x["id"] != document["id"] and x["content_sha256"] == document["content_sha256"]
                 and x.get("format") == document["format"]), None)
    if twin:
        return {"result": "duplicate", "id": document["id"], "duplicate_of": twin["id"], "documents": len(m["documents"])}
    if previous and previous["published_at"] != document["published_at"]:
        raise PublishError("修订必须保留首次 published_at。")
    if previous and previous["content_sha256"] == document["content_sha256"]:
        document["path"] = previous["path"]
    else:
        stored = dav.request("GET", document["path"], missing_ok=True)
        if stored is not None and stored != data:
            raise PublishError("不可变正文路径已有不同内容；已停止，未更新 Manifest。")
        if stored is None:
            dav.request("PUT", document["path"], data=data)
    if strict:
        readback = dav.request("GET", document["path"])
        if len(readback) != len(data) or hashlib.sha256(readback).hexdigest() != document["content_sha256"]:
            raise PublishError("正文回读校验失败，未更新 Manifest。")
    if previous == document and upgraded is False:
        return {"result": "unchanged", "id": document["id"], "documents": len(m["documents"])}
    m["documents"] = [x for x in m["documents"] if x["id"] != document["id"]] + [document]
    m["documents"].sort(key=lambda x: timestamp(x["published_at"]), reverse=True)
    m["generated_at"] = dt.datetime.now(dt.timezone.utc).isoformat()
    encoded = json.dumps(m, ensure_ascii=False, indent=2).encode()
    validate_manifest(encoded)
    if dav.request("GET", "manifest.json", missing_ok=True) != existing:
        raise PublishError("发布期间 Manifest 已变化；请串行执行后重试。")
    dav.request("PUT", "manifest.json", data=encoded)
    confirmed = validate_manifest(dav.request("GET", "manifest.json"))
    if confirmed != m:
        raise PublishError("Manifest 回读不一致；远端可能已更新，请保留本次输入并核对后重试。")
    result = {"result": "published", "id": document["id"], "format": document["format"], "documents": len(confirmed["documents"]), "generated_at": confirmed["generated_at"]}
    if upgraded:
        result["upgraded_to_schema_version"] = SCHEMA_VERSION
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["validate", "status", "publish"])
    body = parser.add_mutually_exclusive_group()
    body.add_argument("--markdown", help="Markdown 正文（.md）")
    body.add_argument("--html", help="单文件静态网页（.html）")
    body.add_argument("--file", help="任意已注册格式的正文，按后缀识别")
    parser.add_argument("--metadata")
    args = parser.parse_args()
    try:
        if args.command == "status":
            data = DAV().request("GET", "manifest.json", missing_ok=True)
            if data is None:
                print(json.dumps({"result": "waiting_for_first_publish"})); return
            m = validate_manifest(data)
            remote_version = m.pop("upgraded_from", None) or m["schema_version"]
            formats = {}
            for d in m["documents"]:
                formats[d["format"]] = formats.get(d["format"], 0) + 1
            result = {"result": "ready", "schema_version": remote_version, "generated_at": m["generated_at"],
                      "documents": len(m["documents"]), "formats": formats}
        else:
            path = args.markdown or args.html or args.file
            if not path or not args.metadata:
                parser.error("需要 --markdown、--html 或 --file 之一，以及 --metadata")
            fmt = "markdown" if args.markdown else "html" if args.html else None
            d, data = prepare(path, args.metadata, fmt)
            if args.command == "validate":
                result = {"result": "valid", "document": d}
            else:
                dav = DAV()
                reject_own_host(data, dav)
                result = publish(dav, d, data)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except (PublishError, OSError) as e:
        # OSError strings may contain private local paths; do not expose them.
        print(str(e) if isinstance(e, PublishError) else "本地文件无法读取，请检查文件与权限。", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()

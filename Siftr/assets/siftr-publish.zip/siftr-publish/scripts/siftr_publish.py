#!/usr/bin/env python3
"""Siftr Content Protocol v1 publisher. Standard library; secrets only from environment."""
import argparse
import base64
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

MANIFEST_LIMIT = 2 * 1024 * 1024
DOCUMENT_LIMIT = 5 * 1024 * 1024

class PublishError(Exception):
    pass

def timestamp(value):
    if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})", value):
        raise PublishError("时间字段必须是含时区的 ISO 8601 时间。")
    try:
        return dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        raise PublishError("时间字段无效。") from None

def safe_path(path, document=False):
    if not isinstance(path, str) or not path or any(c in path for c in "\\%:?#") or any(ord(c) < 32 for c in path):
        raise PublishError("内容路径不安全。")
    parts = path.split("/")
    if any(p in ("", ".", "..") for p in parts) or (document and (len(parts) < 2 or parts[0] != "documents" or not path.endswith(".md"))):
        raise PublishError("内容路径不安全。")

def validate_document(d):
    if not isinstance(d, dict):
        raise PublishError("文档元数据必须是对象。")
    for field in ("id", "title", "category"):
        if not isinstance(d.get(field), str) or not d[field].strip():
            raise PublishError(f"{field} 必须为非空字符串。")
    if len(d["title"]) > 200 or not isinstance(d.get("summary"), str) or len(d["summary"]) > 1000:
        raise PublishError("标题或摘要超出限制或缺失。")
    for key in ("published_at", "updated_at"):
        timestamp(d.get(key))
    safe_path(d.get("path"), document=True)
    if not isinstance(d.get("content_sha256"), str) or not re.fullmatch(r"[0-9a-f]{64}", d["content_sha256"]):
        raise PublishError("SHA-256 格式错误。")
    if type(d.get("size_bytes")) is not int or not 0 <= d["size_bytes"] <= DOCUMENT_LIMIT:
        raise PublishError("文档大小超过限制或字段无效。")
    for key in ("reading_minutes", "source_count"):
        if key in d and (type(d[key]) is not int or d[key] < 0):
            raise PublishError(f"{key} 必须是非负整数。")
    if "tags" in d and (not isinstance(d["tags"], list) or not all(isinstance(t, str) for t in d["tags"])):
        raise PublishError("tags 必须是字符串数组。")
    if "subtitle" in d and not isinstance(d["subtitle"], str):
        raise PublishError("subtitle 必须是字符串。")

def validate_manifest(data):
    if len(data) > MANIFEST_LIMIT:
        raise PublishError("Manifest 超过 2 MiB。")
    try:
        m = json.loads(data)
    except (ValueError, UnicodeError):
        raise PublishError("远端 Manifest 格式错误；已停止发布。") from None
    if not isinstance(m, dict) or type(m.get("schema_version")) is not int or m["schema_version"] != 1:
        raise PublishError("不支持的 Manifest 协议版本。")
    timestamp(m.get("generated_at"))
    docs = m.get("documents")
    if not isinstance(docs, list) or len(docs) > 5000:
        raise PublishError("documents 必须是最多 5000 条的数组。")
    ids = set()
    for d in docs:
        validate_document(d)
        if d["id"] in ids:
            raise PublishError("Manifest 中存在重复 ID。")
        ids.add(d["id"])
    return m

def prepare(markdown, metadata):
    data = Path(markdown).read_bytes()
    if not data or len(data) > DOCUMENT_LIMIT:
        raise PublishError("Markdown 为空或超过 5 MiB。")
    try:
        text = data.decode("utf-8")
        d = json.loads(Path(metadata).read_text(encoding="utf-8"))
    except (UnicodeError, ValueError):
        raise PublishError("Markdown 必须是 UTF-8，元数据必须是 JSON。") from None
    if not text.strip():
        raise PublishError("Markdown 不得为空白。")
    if re.search(r"<\s*(script|iframe|object|embed)\b", text, re.I):
        raise PublishError("Markdown 包含不允许的 HTML 内容。")
    if re.search(r"(https?://[^\s/]+:[^\s/]+@|Authorization\s*:|SIFTR_DAV_APP_PASSWORD\s*=)", text, re.I):
        raise PublishError("Markdown 可能含有凭证，禁止发布。")
    if text.count("```") % 2:
        raise PublishError("Markdown 代码围栏未闭合。")
    for link in re.findall(r"\]\(([^\s)]+)", text):
        if link.startswith("media/"):
            if not link.lower().endswith((".png", ".jpg", ".jpeg", ".gif", ".webp")):
                raise PublishError("media/ 引用必须是 png/jpg/jpeg/gif/webp 图片。")
            safe_path(link)
            continue
        u = urllib.parse.urlsplit(link)
        if u.scheme not in ("https", "http") or not u.hostname or u.username or u.password:
            raise PublishError("正文链接必须是无凭证的 HTTP(S) 地址。")
    if not isinstance(d, dict) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,199}", str(d.get("id", ""))):
        raise PublishError("发布 ID 必须是最多 200 字符的 ASCII 标识。")
    sha = hashlib.sha256(data).hexdigest()
    # Full hash prevents rare hash8 collisions from violating immutable paths.
    d.update(path=f"documents/{d['id'][:180]}_{sha}.md", content_sha256=sha, size_bytes=len(data))
    validate_document(d)
    return d, data

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise PublishError("服务器重定向已被拒绝；不会转发凭证。")

class DAV:
    def __init__(self):
        self.root = os.environ.get("SIFTR_DAV_URL", "")
        user = os.environ.get("SIFTR_DAV_USER", "")
        password = os.environ.get("SIFTR_DAV_APP_PASSWORD", "")
        u = urllib.parse.urlsplit(self.root)
        if u.scheme != "https" or not u.hostname or u.username or u.password or u.query or u.fragment or not user or not password or ":" in user:
            raise PublishError("请通过运行环境提供有效 HTTPS 地址、账号及应用密码。")
        safe_path(u.path.strip("/"))
        self.root = self.root.rstrip("/") + "/"
        self.auth = "Basic " + base64.b64encode(f"{user}:{password}".encode()).decode()
        self.opener = urllib.request.build_opener(NoRedirect())

    def request(self, method, path="", data=None, missing_ok=False):
        if path:
            safe_path(path)
        # 坚果云对带尾斜杠的 MKCOL 返回 409；空路径（根目录）必须用去斜杠的 URL。
        url = (self.root + urllib.parse.quote(path, safe="/")) if path else self.root.rstrip("/")
        for attempt in range(3):
            req = urllib.request.Request(url, data=data, method=method, headers={"Authorization": self.auth, "Content-Type": "application/json" if path.endswith(".json") else "text/markdown; charset=utf-8"})
            try:
                with self.opener.open(req, timeout=30) as response:
                    limit = MANIFEST_LIMIT if path.endswith(".json") else DOCUMENT_LIMIT
                    result = response.read(limit + 1)
                    if len(result) > limit:
                        raise PublishError("远端响应超过大小限制。")
                    return result
            except urllib.error.HTTPError as e:
                # 空目录首次发布时，坚果云对「父目录不存在」的路径返回 409 AncestorsNotFound
                # 而不是 404；两种都算「还没有 Manifest」，让 publish 走 initialize() 建目录。
                if missing_ok and e.code in (404, 409):
                    return None
                if e.code in (401, 403):
                    raise PublishError("认证失败，请检查应用密码。") from None
                if method == "MKCOL" and e.code == 405:
                    return b""
                if e.code == 429 or 500 <= e.code <= 599:
                    delay = e.headers.get("Retry-After", "")
                    delay = float(delay) if delay.isdigit() else 2 ** attempt
                    if attempt < 2 and delay <= 30:
                        time.sleep(max(1, delay)); continue
                    raise PublishError("服务器限流或暂时不可用，请稍后重试。") from None
                raise PublishError(f"WebDAV {method} 失败（HTTP {e.code}）。") from None
            except (urllib.error.URLError, TimeoutError):
                if attempt < 2:
                    time.sleep(2 ** attempt); continue
                raise PublishError("无法连接服务器，请检查网络。") from None
        raise PublishError("请求失败。")

    def initialize(self):
        # MKCOL root, documents and media only; never delete or overwrite historical files.
        self.request("MKCOL")
        self.request("MKCOL", "documents")
        self.request("MKCOL", "media")

def publish(dav, document, data, strict=True):
    existing = dav.request("GET", "manifest.json", missing_ok=True)
    if existing is None:
        dav.initialize()
        m = {"schema_version": 1, "generated_at": dt.datetime.now(dt.timezone.utc).isoformat(), "documents": []}
        # The publisher identity is optional metadata, not a constant of this script.
        publisher = document.get("publisher")
        if isinstance(publisher, str) and publisher.strip():
            m["publisher"] = publisher.strip()
    else:
        m = validate_manifest(existing)
    previous = next((x for x in m["documents"] if x["id"] == document["id"]), None)
    # The reader shows identical Markdown once, so a second id carrying the same bytes is only noise.
    # Nothing is written; the caller learns which published id already holds this content.
    twin = next((x for x in m["documents"] if x["id"] != document["id"] and x["content_sha256"] == document["content_sha256"]), None)
    if twin:
        return {"result": "duplicate", "id": document["id"], "duplicate_of": twin["id"], "documents": len(m["documents"])}
    if previous and previous["content_sha256"] == document["content_sha256"]:
        document["path"] = previous["path"]
    else:
        dav.request("PUT", document["path"], data=data)
    if strict:
        readback = dav.request("GET", document["path"])
        if len(readback) != len(data) or hashlib.sha256(readback).hexdigest() != document["content_sha256"]:
            raise PublishError("正文回读校验失败，未更新 Manifest。")
    if previous == document:
        return {"result": "unchanged", "id": document["id"], "documents": len(m["documents"])}
    m["documents"] = [x for x in m["documents"] if x["id"] != document["id"]] + [document]
    m["documents"].sort(key=lambda x: timestamp(x["published_at"]), reverse=True)
    m["generated_at"] = dt.datetime.now(dt.timezone.utc).isoformat()
    encoded = json.dumps(m, ensure_ascii=False, indent=2).encode()
    validate_manifest(encoded)
    dav.request("PUT", "manifest.json", data=encoded)
    confirmed = validate_manifest(dav.request("GET", "manifest.json"))
    if not any(x == document for x in confirmed["documents"]):
        raise PublishError("Manifest 回读不一致，请重试发布。")
    return {"result": "published", "id": document["id"], "documents": len(confirmed["documents"]), "generated_at": confirmed["generated_at"]}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["validate", "status", "publish"])
    parser.add_argument("--markdown")
    parser.add_argument("--metadata")
    args = parser.parse_args()
    try:
        if args.command == "status":
            data = DAV().request("GET", "manifest.json", missing_ok=True)
            if data is None:
                print(json.dumps({"result": "waiting_for_first_publish"})); return
            m = validate_manifest(data)
            result = {"result": "ready", "generated_at": m["generated_at"], "documents": len(m["documents"])}
        else:
            if not args.markdown or not args.metadata:
                parser.error("需要 --markdown 和 --metadata")
            d, data = prepare(args.markdown, args.metadata)
            result = {"result": "valid", "document": d} if args.command == "validate" else publish(DAV(), d, data)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except (PublishError, OSError) as e:
        # OSError strings may contain private local paths; do not expose them.
        print(str(e) if isinstance(e, PublishError) else "本地文件无法读取，请检查文件与权限。", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
